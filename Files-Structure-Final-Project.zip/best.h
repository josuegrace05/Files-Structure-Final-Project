#ifndef BEST_H
#define BEST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"

int remove_registro_best(char *, INDICE **, int * );

void listar_best_removidos();	
int inserir_best(INDICE **, int *, int ,  REGISTRO *);
#endif


//04.913.711/0001-08
//03.468.907/0001-78
//62.232.889/0001-90
//02.036.233/0001-70
//33.147.315/0001-15
//33.349.358/0001-83